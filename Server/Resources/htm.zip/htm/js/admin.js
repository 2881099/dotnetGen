﻿$.ajaxSettings.dataType = 'json';
$.ajaxSettings.error = function(jqXHR, textStatus, errorThrown) {
	if (jqXHR.status == 501) {
		alert("您还没有登陆");
		location.reload();
	}
};

// 最后特效，一定要放在页面底部
function tr_mouseover() {
	$('form tr td').unbind('mouseover').mouseover(function(){$(this).parent().children().css('background-color',function(index,value){if(!this.oldbgcolor)this.oldbgcolor=value;return '#eee';});});
	$('form tr td').unbind('mouseout').mouseout(function(){$(this).parent().children().css('background-color',function(index,value){return this.oldbgcolor;})});
}

function admin_init($, nav) {
	window.nav = nav;
	var div_left_router = window.div_left_router;
	var pathname = nav.url.split('?')[0];

	$(".select2").select2();
	$('[data-mask]').inputmask();
	var submit = $('form#form_add input[type="submit"]');
	$('form#form_add').submit(function (e) {
		if (submit.val() == '更新')
			if (!confirm('确认要更新数据吗？')) {
				e.stopImmediatePropagation();
				return false;
			}
	});
	$('form#form_add input[type="button"][value="取消"]').attr('onclick', '').unbind().click(function () {
		nav.goto('./');
	});
	$('table tr').each(function (i, el) {
		var td = $(el).find('td')
		if (td.length === 2) td[0].style.width = '8%';
	});
	//$('table#GridView1 tr th:last').css('width', '60px').prev().css('width', '60px');
	//设置页面title
	for (var a in div_left_router) {
		var tmp1 = pathname;
		var title = div_left_router[a];
		var ele_href = a;
		if (!ele_href) continue;
		tmp1 = tmp1.replace(/\/(del|edit|add)\.aspx$/i, function ($0, $1, $2) {
			if ($1 === 'edit' || $1 === 'add') title = title + ' - ' + submit.val();
			return '/';
		});
		if (ele_href.indexOf(tmp1) != -1) {
			document.title2 = document.title2 || document.title;
			document.title = title + ' - ' + document.title2;
			$('#box-title:first').html(title + ' <font color="#aaa">({0})</font>'.format(nav.url));
			break;
		}
	}
	$('#btn_delete_sel').click(function () {
		if (confirm('操作不可逆，确认要删除选择项吗？')) {
			$('form#form_list').attr('action', './del.aspx');
			$('form#form_list').submit();
		}
		return false;
	});
	//处理multi_status，多选字段
	var multi_status_count = 0;
	$('input[multi_status]').each(function (index, el) {
		el = $(el);
		var status = el.attr('multi_status').split(',');
		var val = el.val();
		if (isNaN(parseInt(val, 10))) el.val(val = 0);
		for (var a = 0; a < status.length; a++) {
			var chkid = 'multi_status_checkbox_' + multi_status_count++;
			var chk = $('<input type="checkbox" id="' + chkid + '"' +
				((val & Math.pow(2, a)) == Math.pow(2, a) ? ' checked' : '') +
				' onclick=""/><label for="' + chkid + '">' + status[a] + '</label>');
			el.before(chk);
			(function (a) {
				$('#' + chkid).click(function () {
					el.val(val = parseInt(val, 10) + (this.checked ? 1 : -1) * Math.pow(2, a));
				});
			})(a);
		}
	});
	//处理百度编辑器
	$('textarea').each(function (i, el) {
		if (el.style.width === '100%') {
			new baidu.editor.ui.Editor({
				scaleEnabled: true
			}).render(el);
		}
	});
	//处理table中长文本显示问题
	$('form#form_list td').each(function (index, ele) {
		var html = ele.innerHTML.trim('');
		if (!/<[^>]+>/gi.test(html)) {
			if (html.getLength() > 36) $(ele).html('').append($('<div></div>').attr('title', html).html(html.left(36) + '...'));
		} else $(ele).find('a').each(function(index, ele) {
			var html = ele.innerHTML;
			if (html.getLength() > 36) $(ele).html(html.left(36) + '...').attr('title', html);
		});
	});
	$('img').each(function (idx, ele) {
		ele = $(ele);
		var src = nav.trans(ele.attr('src'));
		ele.attr('src', src);
	});
	$('a').click(function () {
		var href = $(this).attr('href');
		if (!href || href.substr(0, 1) === '#') return false;
		nav.goto(href, $(this).attr('target'));
		return false;
	});
	$('form').submit(function () {
		if (this.method.toLowerCase() == 'post') {
			nav.goto(this);
			return true;
		}
		var act = $(this).attr('action') || '';
		var qs = qs_parseByUrl(act);
		qs = qs_stringify(qs) + '&' + url_decode($(this).serialize());
		qs = qs_parse(qs);
		qs = qs_stringify(qs);
		nav.goto(act.split('?', 2)[0] + '?' + qs);
		return false;
	});
	tr_mouseover();
}
